#!/bin/sh

# setup PPA of jdk8
apt-get install -y software-properties-common
add-apt-repository -y ppa:webupd8team/java
apt-get update && apt-get install -y oracle-java8-installer

# install jdk8
apt-get update
apt-get install -y openjdk-8-jdk
