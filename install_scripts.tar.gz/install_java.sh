#!/bin/sh

# install jdk8
apt-get update
apt-get install -y openjdk-8-jdk
