#!/bin/sh

# setup PPA of jdk8
sudo add-apt-repository ppa:webupd8team/java
sudo apt-get update && sudo apt-get install oracle-java8-installer

# install jdk8
apt-get update
apt-get install -y openjdk-8-jdk
