#!/bin/sh

# install python
apt-get install -y python
