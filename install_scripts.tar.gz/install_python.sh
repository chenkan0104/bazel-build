#!/bin/sh

# install python
apt-get update
apt-get install -y python
