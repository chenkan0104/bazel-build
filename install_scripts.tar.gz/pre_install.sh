#!/bin/sh

# change sources to mirror in China
mv /etc/apt/sources.list /etc/apt/sources.list.save
mv sources.list /etc/apt/sources.list

# set timezone
echo Asia/Shanghai > /etc/timezone && dpkg-reconfigure --frontend noninteractive tzdata
